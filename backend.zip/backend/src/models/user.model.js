import mongoose,{Schema} from "mongoose";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";


const userSchema = new Schema(
    {
        username:{
            type:String,
            required:true,
            unique:true,
            lowercase:true,
            trim:true,
            index:true
        },
        email:{
            type:String,
            required:true,
            unique:true,
            lowercase:true,
            trim:true,
        },
        phone: {
            type: String,
            required: true,
            unique: true,
        },
        password:{
            type: String,
            required:[true,"Password is required"]
        },
        role: {
            type: String,
            enum: ["customer","shop_owner","delivery"],
            default: "customer",
            required: true
        },
        avatar:{
            type: String, //cloudinary url using
            required:true,
        },
        addresses: [
        {
            label: { type: String, default: "Home" }, // Home / Work / Other
            addressLine: String,
            city: String,
            pincode: String,
            location: {
            type: { type: String, enum: ["Point"], default: "Point" },
            coordinates: { type: [Number], default: [0, 0] }, // [lng, lat]
            },
            isDefault: { type: Boolean, default: false },
        },
        ],
        refreshToken:{
            type: String
        }


    },
    {timestamps:true}
)

userSchema.pre("save",async function (next) {
    if(!this.isModified("password")) return ;
    
    this.password = await bcrypt.hash(this.password,10)
    
})

userSchema.methods.isPasswordCorrect = async function name(password) {
    return await bcrypt.compare(password,this.password)
}

userSchema.methods.generateAccessToken = function(){
    return jwt.sign(
        {
            _id:this._id,
            email:this.email,
            username:this.username,
            role: this.role
            
        },
        process.env.ACCESS_TOKEN_SECRET,
        {
            expiresIn: process.env.ACCESS_TOKEN_EXPIRY
        }
    )
}


userSchema.methods.generateRefreshToken = function(){
    return jwt.sign(
        {
            _id:this._id,
            
        },
        process.env.REFRESH_TOKEN_SECRET,
        {
            expiresIn: process.env.REFRESH_TOKEN_EXPIRY
        }
    )
}


export const User = mongoose.model("User",userSchema)